﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Delegados
{
    public partial class frmPrincipal : Form
    {
        public ActualizarNombrePorDelegado Actualizar;

        public frmPrincipal()
        {
            InitializeComponent();

        }

        private void testDelegadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTestDelegados frm = new frmTestDelegados();
            frm.Show(this);
        }

        private void testToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDatos frm = new frmDatos();
            frm.Show(this);
            this.Actualizar = frm.ActualizarNombre;
        }
    }
}
