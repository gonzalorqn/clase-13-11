﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrmPrincipal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        void ManejadorCentral(object obj,EventArgs e)
        {
            if(obj.Equals(this.button1))
            {
                this.button1.Click -= new EventHandler(MiManejadorClick);
                this.button1.Click -= new EventHandler(ManejadorCentral);
                this.button2.Click += new EventHandler(MiManejadorClick);
                this.button2.Click += new EventHandler(ManejadorCentral);
            }
            else if (obj.Equals(this.button2))
            {
                this.button2.Click -= new EventHandler(MiManejadorClick);
                this.button2.Click -= new EventHandler(ManejadorCentral);
                this.textBox1.Click += new EventHandler(MiManejadorClick);
                this.textBox1.Click += new EventHandler(ManejadorCentral);
            }
            else if (obj.Equals(this.textBox1))
            {
                this.button1.Click += new EventHandler(MiManejadorClick);
                this.button1.Click += new EventHandler(ManejadorCentral);
                this.textBox1.Click -= new EventHandler(MiManejadorClick);
                this.textBox1.Click -= new EventHandler(ManejadorCentral);
            }
        }

        void MiManejadorClick(object obj,EventArgs e)
        {
            MessageBox.Show(((Control)obj).Name);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //this.button1.Click += new EventHandler(MiManejadorClick);
            //this.button2.Click += new EventHandler(MiManejadorClick);
            //this.textBox1.Click += new EventHandler(MiManejadorClick);
            //this.button1.Click += new EventHandler(CambiarFondo);
            //this.button2.Click += new EventHandler(MiOtroManejador);
            this.button1.Click += new EventHandler(MiManejadorClick);
            this.button1.Click += new EventHandler(ManejadorCentral);
        }

        void MiOtroManejador(object obj,EventArgs e)
        {
            this.button2.Click += new EventHandler(MiManejadorClick);
            this.button1.Click -= new EventHandler(MiManejadorClick);
        }

        void CambiarFondo(object obj,EventArgs e)
        {
            ((Control)obj).BackColor = Color.Green;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.button1.Click -= new EventHandler(MiManejadorClick);
            this.button2.Click -= new EventHandler(MiManejadorClick);
            this.textBox1.Click -= new EventHandler(MiManejadorClick);
            this.button1.Click -= new EventHandler(CambiarFondo);
        }
    }
}
